package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.qa.zerobank.base.BaseTest;

public class LogInPage extends BaseTest {
	
	
	@FindBy(id ="user_login")
	WebElement username;



	@FindBy(id="user_password")
	WebElement password;



	@FindBy(name="user_remember_me")
	WebElement checkbox;



	@FindBy(id="credentials")
	WebElement questionmark;



	@FindBy(name="submit")
	WebElement signin;



	@FindBy(id="details-button")
	WebElement detailbutton;



	@FindBy(id="proceed-link")
	WebElement proceedlink;




	public LogInPage() {



	PageFactory.initElements(driver, this);



	}



	public void assertHomePageTitle() {



	assertEquals(driver.getTitle(), "Zero - Log in", "Mismatch found");



	}



	public AccountSummaryPage loginPage() {



	username.sendKeys(prop.getProperty("username"));
	password.sendKeys(prop.getProperty("password"));
	signin.click();
	detailbutton.click();
	proceedlink.click();
	return new AccountSummaryPage();
	}
	public void invalidLogin(String uname,String Pass) {
		username.sendKeys(uname);
		password.sendKeys(Pass);
		signin.click();
		String text = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();
		Assert.assertEquals(text, "Login and/or password are wrong.", "Text is not matching");
	}
	}
