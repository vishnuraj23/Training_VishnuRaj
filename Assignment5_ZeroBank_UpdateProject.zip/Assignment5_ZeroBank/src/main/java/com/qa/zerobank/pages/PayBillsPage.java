package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.testng.Assert;

import com.qa.zerobank.base.BaseTest;
/**
 * @author Vishnu Raj
 *
 */
public class PayBillsPage extends BaseTest{
	@FindBy(partialLinkText  = "Purchase Foreign Cur")
	WebElement Purchase_Foreign_Currency_Tab;
	
	@FindBy(xpath  = "//h2[text()='Make payments to your saved payees']")
	WebElement Make_payments_to_your_saved_payees_txt;
	
	@FindBy(xpath  = "//h2[text()='Purchase foreign currency cash']")
	WebElement Purchase_foreign_currency_cash_txt;
	
	@FindBy(xpath  = "//input[@value='Purchase']")
	WebElement Purchase_btn;
	
	@FindBy(linkText =  "Transfer Funds")
	WebElement TransferFunds;
	@FindBy(partialLinkText  =  "Pay Saved Payee")
	WebElement paysavepayee;
	@FindBy(xpath  =  "//input[@value='Pay']")
	WebElement pay_btn;
	@FindBy(xpath = "//h2[text()='Make payments to your saved payees']")
	WebElement MakePaymetTxt;
	@FindBy(id = "sp_amount")
	WebElement amount;
	@FindBy(id = "sp_description")
	WebElement Desc;

	// constructor
	public PayBillsPage() {
		PageFactory.initElements(driver, this);
	}

	// assert title
	public void assertPayBillsPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Pay Bills");
	}
	public void Click_Purchase_Foreign_Currency_Tab() {
		Purchase_Foreign_Currency_Tab.click();
		
	}
	
	public void PurchaseForeignCurrencySection() {
		
		Purchase_btn.click();
		
	}
	public void PurchaseForeignCurrency_Alert() {
		
		String alert = driver.switchTo().alert().getText();
		Assert.assertEquals(alert, "Please, ensure that you have filled all the required fields with valid values.",
				"Alert text is not matching");
		System.out.println(alert);
		driver.switchTo().alert().accept();

	}
	public void NegativePaySavedPayee() {
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		paysavepayee.click();
		amount.sendKeys(prop.getProperty("Amount"));
		Desc.sendKeys(prop.getProperty("Desc"));
		pay_btn.click();
		String Text = MakePaymetTxt.getText();
		Assert.assertEquals(Text, "Make payments to your saved payees");
		
	}
	public TransferFundsPage NavigateTransferFunds() {


		TransferFunds.click();
		
		return new TransferFundsPage();
		}
}
