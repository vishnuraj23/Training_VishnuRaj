package com.qa.zerobank.pages;

import com.qa.zerobank.base.BaseTest;

/**
 * @author Vishnu Raj
 *
 */
public class OnlineBankingPage extends BaseTest{

}
