package com.qa.zerobank.testcases;

import static org.testng.Assert.assertTrue;


import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.zerobank.base.BaseTest;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PayBillsPage;
import com.qa.zerobank.pages.TransferFundsPage;
import com.qa.zerobank.util.Testutil;
/**
 * @author Vishnu Raj
 *
 */
public class Assignment5_Testcases extends BaseTest {
	HomePage homepage;
	LogInPage loginpage;
	AccountSummaryPage accountsummarypage;
	PayBillsPage paybillspage;
	TransferFundsPage transferfundspage;
	String path = System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\zerobank\\testdata\\";
	String name = "Test_Data.xlsx";
	String Sheetname= "LogIn";
	public Assignment5_Testcases() {
		super();

	}
	/**
	 * initialization of driver from base class
	 *
	 */
	@BeforeTest
	public void setup() {
		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
		accountsummarypage = new AccountSummaryPage();
		paybillspage = new PayBillsPage();
		transferfundspage = new TransferFundsPage();
		
	}
	/**
	 * Kill the driver
	 *
	 */
	@AfterTest
	public void quit() {
		Testutil.TakeScreenshot("Close");
		driver.close();
		driver.quit();

	}
	/**
	 * Verify the logo and home page
	 *
	 */
	@Test(priority = 0)
	public void ValidateHomePage() {
		homepage.assertHomePageTitle();
		assertTrue(homepage.VerifyLogo());
		loginpage = homepage.clickOnSignInButton();
		Testutil.TakeScreenshot("login");
	}
	/**
	 * Verify the login page with Invalid username and password
	 *
	 */
	@Test(priority = 1, dataProvider = "WrongLoginDetails")
	public void ValidateLoginFunction(String sname, String Pass) {

		loginpage.assertHomePageTitle();
		loginpage.invalidLogin(sname, Pass);
		Testutil.TakeScreenshot("Invalid_login");
	}
	/**
	 * Verify the login page with valid username and password
	 *
	 */
	@Test(priority = 2)
	public void LogintoApplication() {

		accountsummarypage = loginpage.loginPage();
		accountsummarypage.assertLoginPageTitle();
		Testutil.TakeScreenshot("login");
	}
	/**
	 * Validate with invalid details in the Pay Bills page
	 *
	 */
	@Test(priority = 3)
	public void ValidatePayBills() {

		paybillspage = accountsummarypage.ClickPayBills();
		paybillspage.assertPayBillsPageTitle();
		paybillspage.Click_Purchase_Foreign_Currency_Tab();
		paybillspage.PurchaseForeignCurrencySection();
		paybillspage.PurchaseForeignCurrency_Alert();
		Testutil.TakeScreenshot("ValidatePayBills");
	}
	/**
	 * Validate with invalid details in the Pay Save Payee page
	 *
	 */	
	@Test(priority = 4)
	public void ValidatePaySavePayee() {

		paybillspage.NegativePaySavedPayee();
		Testutil.TakeScreenshot("ValidatePaySavePayee");
	}
	/**
	 * Validate with invalid details in the Transfer Money And Make Payments page
	 *
	 */	
	@Test(priority = 5)
	public void ValidateTransferMoneyAndMakePayments() {
		transferfundspage = paybillspage.NavigateTransferFunds();
		transferfundspage.InvalidateTransferMoneyAndMakePayments();
		Testutil.TakeScreenshot("ValidateTransferMoneyAndMakePayments");

	}
	/**
	 * Verify the Transfer Money And Make Payments
	 *
	 */	
	@Test(priority = 6)
	public void TransferMoneyAndMakePayments() {
		transferfundspage.ValidateTransferMoneyAndMakePayments();
		Testutil.TakeScreenshot("TransferMoneyAndMakePayments");

	}
	

	@DataProvider
	public Object[][] WrongLoginDetails() throws Exception {

		
			Object data[][]= Testutil.getExcelData(path, name, Sheetname);
			return data;
					
			
	}
}
