/**
 * 
 */
package ZeroBank;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * @author Vishnu Raj
 *
 */
public class ZeroBank_Purchaseforeigncurrency {

	/**
	 * @param args
	 */
	public static WebDriver driver;
	public static WebDriverWait ExplicitWait;

	@BeforeSuite(alwaysRun = true)
	public static void Setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(options);
		// maximize the window
		driver.manage().window().maximize();
		// open url
		driver.get("http://zero.webappsecurity.com/");

	}

	@BeforeTest(groups = { "smoke" })
	@Parameters({ "username", "password" })
	public static void Login(String username, String password) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Login to Zero Bank
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.name("user_login")).sendKeys(username);
		driver.findElement(By.cssSelector("input[name='user_password']")).sendKeys(password);
		driver.findElement(By.xpath("//*[@value='Sign in']")).click();
		// Browser Advance option
		waittime();
		if (driver.findElement(By.id("details-button")).isDisplayed()) {
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.id("proceed-link")).click();
		}
	}

	@Test(priority = 4, enabled = true, groups = { "Regression" }, dataProvider = "WrongLoginDetails")
	public static void NegativeLogin(String username, String password) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://zero.webappsecurity.com/");
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.name("user_login")).sendKeys(username);
		driver.findElement(By.cssSelector("input[name='user_password']")).sendKeys(password);
		driver.findElement(By.xpath("//*[@value='Sign in']")).click();
		String text = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();
		Assert.assertEquals(text, "Login and/or password are wrong.", "Text is not matching");
	}

	@Test(priority = 2, enabled = true, groups = { "smoke" })
	public static void PurchaseForeignCurrency() {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Pay Bills")).click();
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(
				driver.findElement(By.xpath("//h2[text()='Make payments to your saved payees']")),
				"Make payments to your saved payees"));
		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(
				driver.findElement(By.xpath("//h2[text()='Purchase foreign currency cash']")),
				"Purchase foreign currency cash"));
		// Navigate to Purchase Foreign Currency
		driver.findElement(By.partialLinkText("Purchase Foreign Currency")).click();
		// Keeping all the field empty and click on 'purchase' button to handle Alert.
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@value='Purchase']")).click();
		ExplicitWait.until(ExpectedConditions.alertIsPresent());
		String alert = driver.switchTo().alert().getText();
		Assert.assertEquals(alert, "Please, ensure that you have filled all the required fields with valid values.",
				"Alert text is not matching");
		System.out.println(alert);
		driver.switchTo().alert().accept();
	}

	@Test(priority = 3, enabled = true, groups = { "smoke" })
	public static void TransferMoneyAndMakePayments() {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Transfer Funds")).click();
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(
				driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")),
				"Transfer Money & Make Payments"));
		WebElement fromAccountId = driver.findElement(By.name("fromAccountId"));
		Select select = new Select(fromAccountId);
		select.selectByValue("2");
		WebElement To = driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select(To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");
		driver.findElement(By.id("tf_amount")).sendKeys("1000");
		driver.findElement(By.id("tf_description")).sendKeys("test");
		driver.findElement(By.id("btn_submit")).click();
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		String text = driver.findElement(By.xpath("//div[@class='alert alert-success']")).getText();
		Assert.assertEquals(text, "You successfully submitted your transaction.", "The displayed text is not matching");
		System.out.println(text);
		
	}
	@Parameters({ "username", "password" })
	@Test(priority = 5, enabled = true, groups = { "Regression" })
	public static void NegativeTransferMoneyAndMakePayments(String username, String password) {
		driver.navigate().to("http://zero.webappsecurity.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Login to Zero Bank
		Login(username, password);
		driver.findElement(By.linkText("Transfer Funds")).click();
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(
				driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")),
				"Transfer Money & Make Payments"));
		WebElement fromAccountId = driver.findElement(By.name("fromAccountId"));
		Select select = new Select(fromAccountId);
		select.selectByValue("2");
		WebElement To = driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select(To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");
		driver.findElement(By.id("tf_amount")).sendKeys("");
		driver.findElement(By.id("tf_description")).sendKeys("Testing");
		driver.findElement(By.xpath("//button[text()='Continue']")).click();
		String Text = driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")).getText();
		Assert.assertEquals(Text, "Transfer Money & Make Payments");
	}
	
	@Test(priority = 6, enabled = true, groups = { "Regression" })
	public static void NegativeAddPayee() {
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Pay Bills")).click();
		// Navigate to Add New Payee
		driver.findElement(By.partialLinkText("Add New Pay")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Who are you paying?']")), "Who are you paying?"));
		
		// Add New Payee details
		driver.findElement(By.xpath("//input[contains(@id,'np_new_payee_nam')]")).sendKeys("Vishnu Raj");
		driver.findElement(By.cssSelector("textarea#np_new_payee_address")).sendKeys("Address of the new payee");
		driver.findElement(By.xpath("//input[@id='np_new_payee_account']")).sendKeys("");
		driver.findElement(By.xpath("//input[@name='details']")).sendKeys("Details XYZ");
		driver.findElement(By.id("add_new_payee")).click();
		String Text = driver.findElement(By.xpath("//h2[text()='Who are you paying?']")).getText();
		Assert.assertEquals(Text, "Who are you paying?");
	}
	@Test(priority = 7, enabled = true, groups = { "Regression" })
	public static void NegativePaySavedPayee() {
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Pay Bills")).click();
		// Navigate to Add New Payee
		driver.findElement(By.partialLinkText("Pay Saved Payee")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverWait eWait = new WebDriverWait(driver, 10);
		eWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Make payments to your saved payees']")), "Make payments to your saved payees"));
		driver.findElement(By.xpath("//div[@class='controls']//input")).sendKeys("1000");
		driver.findElement(By.xpath("(//div[@class='controls']//input)[3]")).sendKeys("Test XYZ");
		driver.findElement(By.xpath("//input[@value='Pay']")).click();
		String Text = driver.findElement(By.xpath("//h2[text()='Make payments to your saved payees']")).getText();
		Assert.assertEquals(Text, "Make payments to your saved payees");
		
	}

	@AfterClass(alwaysRun = true)
	public static void SignOut() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if (!driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).isDisplayed()) {
			System.out.println("Signout is not present");
		}
		else {
			driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();
			ExplicitWait = new WebDriverWait(driver, 10);
			ExplicitWait.until(ExpectedConditions.visibilityOfAllElements(driver.findElement(By.linkText("Logout"))));
			driver.findElement(By.linkText("Logout")).click();
		}
		
	}

	@AfterTest(alwaysRun = true)
	public static void quitall() {
		// close the browser
		driver.close();
		// Quit the driver
		driver.quit();

	}
	public static void waittime() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
		
	@DataProvider
	public Object[][] LoginDetails() {
		return new Object[][] {

				new Object[] { "username", "password" },

		};
	}

	@DataProvider
	public Object[][] WrongLoginDetails() {

		return new Object[][] {

				new Object[] { "username123", "password@#$" },{ "username1", "password@" } };
	}
}
