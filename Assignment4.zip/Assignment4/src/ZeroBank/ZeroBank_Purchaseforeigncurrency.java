/**
 * 
 */
package ZeroBank;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * @author Vishnu Raj
 *
 */
public class ZeroBank_Purchaseforeigncurrency {

	/**
	 * @param args
	 */
	public static WebDriver driver;
	public static WebDriverWait ExplicitWait;

	@BeforeSuite(groups = {"smoke" })
	public static void Setup() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(options);
		// maximize the window
		driver.manage().window().maximize();
		// open url
		driver.get("http://zero.webappsecurity.com/");

	}
	@BeforeSuite(groups = { "Regression" })
	public static void Setup1() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(options);
		// maximize the window
		driver.manage().window().maximize();
		// open url
		driver.get("http://zero.webappsecurity.com/");

	}

	@BeforeTest(groups = { "smoke" })
	public static void Login() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Login to Zero Bank
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("input[name='user_password']")).sendKeys("password");
		driver.findElement(By.xpath("//*[@value='Sign in']")).click();
		// Browser Advance option
		if (driver.findElement(By.id("details-button")).isDisplayed()) {
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.id("proceed-link")).click();
		}
	}
	
	@Test(priority = 3, enabled = true, groups = { "Regression" })
	public static void NegativeLogin() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Login to Zero Bank
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("input[name='user_password']")).sendKeys("password123");
		driver.findElement(By.xpath("//*[@value='Sign in']")).click();
		String text = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();
		Assert.assertEquals(text, "Login and/or password are wrong.",
				"Text is not matching");
	}

	@Test(priority = 1, enabled = true, groups = { "smoke" })
	public static void PurchaseForeignCurrency() {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Pay Bills")).click();
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Make payments to your saved payees']")), "Make payments to your saved payees"));
		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Purchase foreign currency cash']")), "Purchase foreign currency cash"));
		// Navigate to Purchase Foreign Currency
		driver.findElement(By.partialLinkText("Purchase Foreign Currency")).click();
		// Keeping all the field empty and click on 'purchase' button to handle Alert.
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@value='Purchase']")).click();
		ExplicitWait.until(ExpectedConditions.alertIsPresent());
		String alert = driver.switchTo().alert().getText();
		Assert.assertEquals(alert, "Please, ensure that you have filled all the required fields with valid values.",
				"Alert text is not matching");
		System.out.println(alert);
		driver.switchTo().alert().accept();
	}
	
	@Test(priority = 2, enabled = true, groups = { "smoke" })
	public static void TransferMoneyAndMakePayments() {
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Transfer Funds")).click(); 
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")), "Transfer Money & Make Payments"));
		WebElement fromAccountId = driver.findElement(By.name("fromAccountId")); 
		Select select = new Select(fromAccountId); select.selectByValue("2"); 
		WebElement To=driver.findElement(By.id("tf_toAccountId")); 
		Select sel2 = new Select (To); 
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)"); 
		driver.findElement(By.id("tf_amount")).sendKeys("1000"); 
		driver.findElement(By.id("tf_description")).sendKeys("test"); 
		driver.findElement(By.id("btn_submit")).click();
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		String text = driver.findElement(By.xpath("//div[@class='alert alert-success']")).getText();
		Assert.assertEquals(text, "You successfully submitted your transaction.","The displayed text is not matching");
		System.out.println(text);
	}
	@Test(priority = 4, enabled = true, groups = { "Regression" })
	public static void NegativeTransferMoneyAndMakePayments() {
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Login to Zero Bank
		driver.findElement(By.id("signin_button")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("input[name='user_password']")).sendKeys("password");
		driver.findElement(By.xpath("//*[@value='Sign in']")).click();
		// Browser Advance option
		if (driver.findElement(By.id("details-button")).isDisplayed()) {
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.id("proceed-link")).click();
		}
		driver.findElement(By.linkText("Transfer Funds")).click(); 
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Transfer Money & Make Payments']")), "Transfer Money & Make Payments"));
		WebElement fromAccountId = driver.findElement(By.name("fromAccountId")); 
		Select select = new Select(fromAccountId); select.selectByValue("2"); 
		WebElement To=driver.findElement(By.id("tf_toAccountId")); 
		Select sel2 = new Select (To); 
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)"); 
		driver.findElement(By.id("tf_amount")).sendKeys(""); 
		driver.findElement(By.id("tf_description")).sendKeys("Testing"); 
		driver.findElement(By.xpath("//button[text()='Continue']")).click();
		
			
	}
	

	@AfterTest(groups = { "smoke" })
	public static void SignOut() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();
		ExplicitWait = new WebDriverWait(driver, 10);
		ExplicitWait.until(ExpectedConditions.visibilityOfAllElements(driver.findElement(By.linkText("Logout"))));
		driver.findElement(By.linkText("Logout")).click();
	}
	
	@AfterClass(groups = { "Regression" })
	public static void quitall() {
		// close the browser
		driver.close();
		// Quit the driver
		driver.quit();
		
	}
	
	
	@AfterSuite(groups = { "smoke" })
	public static void quit1() {
		// close the browser
		driver.close();
		// Quit the driver
		driver.quit();
	}

}
