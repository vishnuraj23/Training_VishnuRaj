/**
 * 
 */
package ZeroBank;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * @author Administrator
 *
 */
public class Facebook_login {

	/**
	 * @param args
	 */
	public static WebDriver driver;
	public static WebDriverWait ExplicitWait;
	@BeforeClass(groups = { "Regression" })
	public static void Setup1() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(options);
		// maximize the window
		driver.manage().window().maximize();
		// open url
		driver.get("https://www.facebook.com/login/");

	}

		
	@Test(priority = 5, enabled = true, groups = { "Regression" })
	public static void NegativeLogin() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Login to fb
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		waittime();
		if(driver.findElement(By.xpath("//div[text()='Wrong credentials']")).isDisplayed()) {
			String text = driver.findElement(By.xpath("//div[text()='Wrong credentials']")).getText();
			System.out.println(text);
			Assert.assertEquals(text, "Wrong credentials",
					"Text is not matching");
		}else {
		String text = driver.findElement(By.xpath("(//div[@id='email_container']//div)[2]")).getText();
		System.out.println(text);
		Assert.assertEquals(text, "The email address or mobile number you entered isn't connected to an account. Find your account and log in.",
				"Text is not matching");
		}
	}

	@Test(priority = 6, enabled = true, groups = { "Regression" })
	public static void loginwithoutpassword() {

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Email address or phone number']")).sendKeys("username@gmail.com");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		waittime();
		if(driver.findElement(By.xpath("//div[text()='Wrong credentials']")).isDisplayed()) {
			String text = driver.findElement(By.xpath("//div[text()='Wrong credentials']")).getText();
			System.out.println(text);
			Assert.assertEquals(text, "Wrong credentials",
					"Text is not matching");
		}else {
		String text = driver.findElement(By.xpath("(//div[@id='email_container']//div)[2]")).getText();
		System.out.println(text);
		Assert.assertEquals(text, "The email address you entered isn't connected to an account. Find your account and log in.",
				"Text is not matching");
		}
	}
	
	@Test(priority = 7, enabled = true, groups = { "Regression" })
	public static void loginwithwrongpassword() {
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Email address or phone number']")).clear();
		driver.findElement(By.xpath("//input[@placeholder='Email address or phone number']")).sendKeys("username@gmail.com");
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("password123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		waittime();
		if(driver.findElement(By.xpath("//div[text()='Wrong credentials']")).isDisplayed()) {
			String text = driver.findElement(By.xpath("//div[text()='Wrong credentials']")).getText();
			System.out.println(text);
			Assert.assertEquals(text, "Wrong credentials",
					"Text is not matching");
		}else {
		String text = driver.findElement(By.xpath("(//div[@id='email_container']//div)[2]")).getText();
		System.out.println(text);
		Assert.assertEquals(text,text, "The email address you entered isn't connected to an account. Find your account and log in.");
		}
	}
	
	
	public static void waittime() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
		
	
	@AfterSuite(groups = { "Regression" })
	public static void quit() {
		// close the browser
		driver.close();
		// Quit the driver
		driver.quit();
	}
	
}
